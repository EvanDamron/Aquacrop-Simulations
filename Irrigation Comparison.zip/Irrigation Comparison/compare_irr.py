from matplotlib.colors import ListedColormap
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

irrigation_dfs_15 = []
irrigation_dfs_30 = []
irrigation_dfs_45 = []
irrigation_dfs_np = []

budgets = ['15k', '30k', '45k']

for budget in budgets:
    for i in range(25):
        filename = f'Irrigation Comparison/data/irr_seed5_budget{budget}_map{i}_55.csv'
        df = pd.read_csv(filename, index_col=0)
        df = df.iloc[::7].reset_index(drop=True)
        df = df.iloc[:19].reset_index(drop=True)


        if budget == '15k':
            irrigation_dfs_15.append(df)
        elif budget == '30k':
            irrigation_dfs_30.append(df)
        elif budget == '45k':
            irrigation_dfs_45.append(df)

for i in range(25):
    filename = f'Irrigation Comparison/data/irr_seed5_nonPredictive_map{i}_55.csv'
    df = pd.read_csv(filename, index_col=0)
    df = df.iloc[::7].reset_index(drop=True)
    df = df.iloc[:19].reset_index(drop=True)
    irrigation_dfs_np.append(df)

# Plot only differences

fig, ax = plt.subplots(figsize=(10, 6))

num_diffs = 0
diff_matrix = np.zeros((25, 19))
# Iterate through each pair of DataFrames (map) from 15k and np
for i, (df_15, df_np) in enumerate(zip(irrigation_dfs_15, irrigation_dfs_np)):
    # Compute a binary difference: 1 if different, 0 if same
    # This checks if the 'IrrDay' values differ at each timestep
    diff = (df_15['IrrDay'] != df_np['IrrDay']).astype(int)
    num_diffs += np.sum(diff)
    # diff = (df_np['IrrDay'] > 0).astype(int)
    
    # Get x-values
    x = df_15.index
    
    # Store in array for heatmap
    diff_matrix[i, :] = diff.values

print(f'Total number of differing timesteps: {num_diffs}')

cmap = ListedColormap(['blue', 'orange'])

fig, ax = plt.subplots(figsize=(10, 6))
cax = ax.imshow(diff_matrix, aspect='auto', cmap=cmap)

# Create colorbar
cbar = plt.colorbar(cax, ax=ax)
# We know we have only two values: 0 and 1. Let's set ticks in the middle of these values.
cbar.set_ticks([0.25, 0.75])
cbar.set_ticklabels(['Same', 'Different'])

ax.set_title('Irrigation Differences EB = 15k')
ax.set_xlabel('Timestep')
ax.set_ylabel('Map Index')
plt.tight_layout()
plt.savefig('Irrigation Comparison/Figures_seed5/irr_diff_15k.png')
plt.show()
exit()
# # print(irrigation_dfs)

# Initialize the figure and axes
fig, ax = plt.subplots(figsize=(10, 6))

# Initialize the difference matrix for 4 possibilities
diff_matrix = np.zeros((25, 19))  # 25 maps, 19 timesteps (adjust as needed)

# Iterate through each pair of DataFrames (map) from 15k and np
for i, (df_15, df_np) in enumerate(zip(irrigation_dfs_15, irrigation_dfs_np)):
    # Create a binary difference matrix where:
    # 1: both irrigated
    # 0: neither irrigated
    # 2: np irrigated, 15k didn't
    # 3: np didn't irrigate, 15k did
    diff = np.zeros(df_15.shape[0])

    for j in range(df_15.shape[0]):
        if df_15['IrrDay'].iloc[j] > 0 and df_np['IrrDay'].iloc[j] > 0:
            diff[j] = 1  # both irrigated
        elif df_15['IrrDay'].iloc[j] == 0 and df_np['IrrDay'].iloc[j] == 0:
            diff[j] = 0  # neither irrigated
        elif df_15['IrrDay'].iloc[j] == 0 and df_np['IrrDay'].iloc[j] > 0:
            diff[j] = 3  # np didn't irrigate, 15k did
        elif df_15['IrrDay'].iloc[j] > 0 and df_np['IrrDay'].iloc[j] == 0:
            diff[j] = 2  # np irrigated, 15k didn't

    # Store the difference values in the matrix
    diff_matrix[i, :] = diff

# Define the colormap with 4 colors for each case
cmap = ListedColormap(['lightblue', 'darkblue', 'darkorange', '#FFA07A'])

# Plot the heatmap
fig, ax = plt.subplots(figsize=(10, 6))
cax = ax.imshow(diff_matrix, aspect='auto', cmap=cmap)

# Create colorbar
cbar = plt.colorbar(cax, ax=ax)
cbar.set_ticks([0.4, 1.1, 1.9, 2.6])  # Adjusted to the middle of each color segment
cbar.set_ticklabels(['Neither irrigated', 'Both irrigated', 'np irrigated, 15k didn’t', 'np didn’t irrigate, 15k did'])

# Set the title and labels
ax.set_title('Irrigation Differences EB = 15k')
ax.set_xlabel('Timestep')
ax.set_ylabel('Map Index')

# Adjust layout and save the figure
plt.tight_layout()
plt.savefig('Irrigation Comparison/Figures_seed5/irr_diff_15k_4states.png')
plt.show()